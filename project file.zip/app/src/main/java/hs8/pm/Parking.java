package hs8.pm;

/**
 * Created by jinho on 2017-11-29.
 */

public class Parking extends Thread {
    private String pname;
    private String cnt;
    private String address;
    public Parking(){

    }
    public Parking(String name, String address){
        this.pname = name;
        this.address =address;
    }

    public String getPname() {
        return pname;
    }

    public void setPname(String pname) {
        this.pname = pname;
    }

    public String getCnt() {
        return cnt;
    }

    public void setCnt(String cnt) {
        this.cnt = cnt;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
}
