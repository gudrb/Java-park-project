package hs8.pm;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.design.widget.NavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;


public class RMainActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener ,SensorEventListener{

    TextView name;
    TextView point;
    public static String id="";
    public static Context mContext;

    //sensor
    private long m_lLastTime;
    private float m_fSpeed;
    private float m_fCurX, m_fCurY, m_fCurZ;
    private float m_fLastX, m_fLastY, m_fLastZ;

    private static final int  SHAKE_THRESHOLD = 4000;//임계값

    private SensorManager m_senMng;
    private Sensor m_senAccelerometer;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rmain);
        Intent intent = getIntent();
        id= intent.getStringExtra("id");
        name=(TextView)findViewById(R.id.h_name);
        point=(TextView)findViewById(R.id.h_point);
        m_senMng = (SensorManager)getSystemService(SENSOR_SERVICE);
        m_senAccelerometer=m_senMng.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        mContext = this;


        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.setDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);


//View nav_header_view = navigationView.inflateHeaderView(R.layout.nav_header_main);
        View nav_header_view = navigationView.getHeaderView(0);

        name = (TextView) nav_header_view.findViewById(R.id.h_name);
        point = (TextView)nav_header_view.findViewById(R.id.h_point);

        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        ft.replace(R.id.content_fragment_layout, new ShakeFragment());
        ft.commit();

    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            ((RMainActivity)(RMainActivity.mContext)).onResume();
            super.onBackPressed();
        }
    }


    @Override
    protected void onResume() {
        super.onResume();
        MyPoint task = new MyPoint();
        task.execute(id);
    }

    @Override
    protected void onStart() {
        super.onStart();
        if(m_senAccelerometer != null)
            m_senMng.registerListener(this, m_senAccelerometer, SensorManager.SENSOR_DELAY_GAME);
    }
    public void onStop()
    {

        super.onStop();
        if(m_senMng != null)
            m_senMng.unregisterListener(this);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();
        Fragment fragment = null;
        String title = getString(R.string.app_name);

        if (id == R.id.nav_main) {
            fragment = new ShakeFragment();
            title="SEE-PARK";
        } else if (id == R.id.nav_point) {
            fragment = new AddPointFragment();
            title="포인트 충전";
        } else if (id == R.id.nav_add_parking) {
            fragment = new AddParkFragment();
            title="주차장 등록";
        } else if (id == R.id.nav_s_parking) {
            fragment = new SeeParkFragment();
            title = "주차장 보기";
        }
        else if (id == R.id.nav_b) {
            fragment = new BuyListFragment();
            title = "구매내역";
        }
        if (fragment != null) {
            FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
            ft.replace(R.id.content_fragment_layout, fragment);
            ft.commit();
        }

        // set the toolbar title
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle(title);
        }


        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    @Override
    public void onSensorChanged(SensorEvent event)
    {
        if(event.sensor.getType() == Sensor.TYPE_ACCELEROMETER)
        {
            long lCurTime  = System.currentTimeMillis();
            long lGabOfTime  = lCurTime - m_lLastTime;

            // 0.1초보다 오래되면 다음을 수행 (100ms)
            if(lGabOfTime > 100)
            {
                m_lLastTime = lCurTime;

                m_fCurX = event.values[SensorManager.DATA_X];
                m_fCurY = event.values[SensorManager.DATA_Y];
                m_fCurZ = event.values[SensorManager.DATA_Z];

                // 변위의 절대값에  / lGabOfTime * 10000 하여 스피드 계산
                m_fSpeed = Math.abs(m_fCurX + m_fCurY + m_fCurZ - m_fLastX - m_fLastY - m_fLastZ) / lGabOfTime * 10000;

                // 임계값보다 크게 움직였을 경우 다음을 수행
                if(m_fSpeed > SHAKE_THRESHOLD)
                {
                    Intent intent = new Intent(this,MapActivity.class);
                    startActivity(intent);
                }

                // 마지막 위치 저장
                // m_fLastX = event.values[0]; 그냥 배열의 0번 인덱스가 X값
                m_fLastX = event.values[SensorManager.DATA_X];
                m_fLastY = event.values[SensorManager.DATA_Y];
                m_fLastZ = event.values[SensorManager.DATA_Z];
            }
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }

    class MyPoint extends AsyncTask<String, Void, Void> {

        String data = "";//

        ProgressDialog progressDialog;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog = ProgressDialog.show(RMainActivity.this,
                    "Please Wait", null, true, true);
        }


        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);
            Log.d("TAG","===="+data);
            String[] temp = data.split(",");
           name.setText(temp[0]+"");
           point.setText(temp[1]);
            progressDialog.cancel();
        }


        @Override
        protected Void doInBackground(String... params) {

            String id = (String)params[0];



            String serverURL = "http://mediuu.cafe24.com/getpoint.php";
            String postParameters ="id=" + id;


            try {

                URL url = new URL(serverURL);
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();


                httpURLConnection.setReadTimeout(5000);
                httpURLConnection.setConnectTimeout(5000);
                httpURLConnection.setRequestMethod("POST");
                //httpURLConnection.setRequestProperty("content-type", "application/json");
                httpURLConnection.setDoInput(true);
                httpURLConnection.connect();
                OutputStream outputStream = httpURLConnection.getOutputStream();
                outputStream.write(postParameters.getBytes("UTF-8"));
                outputStream.flush();
                outputStream.close();


/* 서버 -> 안드로이드 파라메터값 전달 */
                InputStream is = null;
                BufferedReader in = null;

                is = httpURLConnection.getInputStream();
                in = new BufferedReader(new InputStreamReader(is), 8 * 1024);
                String line = null;
                StringBuffer buff = new StringBuffer();
                while ( ( line = in.readLine() ) != null )
                {
                    buff.append(line + "\n");
                }
                data = buff.toString().trim();



            } catch (Exception e) {

                //  Log.d(TAG, "InsertData: Error ", e);

                e.printStackTrace();
            }
            return null;
        }
    }

}
