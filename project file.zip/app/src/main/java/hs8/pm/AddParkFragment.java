package hs8.pm;


import android.app.ProgressDialog;
import android.app.TimePickerDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import static android.app.Activity.RESULT_OK;
import static android.content.ContentValues.TAG;


/**
 * A simple {@link Fragment} subclass.
 */
public class AddParkFragment extends Fragment {

View view;
    TextView ed_s;
    TextView ed_e;
    EditText addr;
    EditText phone;
    EditText daddr;
    EditText cost;
    MyAP task;

    final int REQUEST_ACT =1;
    public AddParkFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_add_park, container, false);
        addr= (EditText)view.findViewById(R.id.add_park_address) ;
       ed_s = (TextView) view.findViewById(R.id.start_time);
      ed_e = (TextView) view.findViewById(R.id.end_time);
        phone = (EditText)view.findViewById(R.id.add_park_phone) ;
        daddr=(EditText)view.findViewById(R.id.add_park_daddress);
        cost = (EditText)view.findViewById(R.id.add_park_cost);
        task =new MyAP();
        task.execute(RMainActivity.id);
        ed_s.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                TimePickerDialog.OnTimeSetListener mTimeSetListener =
                        new TimePickerDialog.OnTimeSetListener() {
                            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                                String t = adjustTime(hourOfDay,minute);
                                ed_s.setText(t);
                            }
                        };
                TimePickerDialog alert = new TimePickerDialog(getActivity(),
                        mTimeSetListener, 0, 0, false);
                alert.show();
            }
        });
        ed_e.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                TimePickerDialog.OnTimeSetListener mTimeSetListener =
                        new TimePickerDialog.OnTimeSetListener() {
                            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                                String t = adjustTime(hourOfDay,minute);
                                ed_e.setText(t);
                            }
                        };
                TimePickerDialog alert = new TimePickerDialog(getActivity(),
                        mTimeSetListener, 0, 0, false);
                alert.show();
            }
        });
        Button button = (Button)view.findViewById(R.id.btn_addPark);
        button.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                String _phone="";
                String _addr = "";
                String _daddr="";
                String _ed_s="";
                String _ed_e="";
                String _cost = "";

                _phone =  phone.getText().toString();
                _addr =  addr.getText().toString();
                _daddr = daddr.getText().toString();
                _ed_s = ed_s.getText().toString();
                _ed_e =  ed_e.getText().toString();
                _cost = cost.getText().toString();
                if(_phone.equals("")||_addr.equals("")||_daddr.equals("")||_ed_s.equals("")||_ed_e.equals("")||_cost.equals(""))
                    Toast.makeText(getActivity(), "모든 정보를 입력해주세요.", Toast.LENGTH_SHORT).show();
                else {
                    AddParking task = new AddParking();
                    task.execute(RMainActivity.id, _phone ,_addr, _daddr, _ed_s,_ed_e, _cost);
                }
            }
        });
        addr.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
               Intent intent = new Intent(getActivity(),AddressActivity.class);
                startActivityForResult(intent, REQUEST_ACT);

            }
        });
        return view;
    }
    String adjustTime(int hourOfday, int minute){
        String result="";
        if(hourOfday>=12){
            result=result+"오후 ";
            if(hourOfday>12){
                hourOfday=hourOfday%12;
                result=result+hourOfday;
            }
            else
                result=result+hourOfday;
        }
        else{
            result=result+"오전 ";
            if(hourOfday==0)
                result=result+"12";
            else
                result=result+hourOfday;
        }
        result=result+":";
        if(minute==0)
            result=result+"00";
        else
            result=result+minute;

        return result;
    }
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK) {
            addr.setText("");
            return;
        }
        if (requestCode == REQUEST_ACT) {
            String resultMsg = data.getStringExtra("result_msg");
            addr.setText(resultMsg);
        }

    }

    class MyAP extends AsyncTask<String, Void, Void> {

        String data = "";//

        ProgressDialog progressDialog;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog = ProgressDialog.show(getActivity(),
                    "Please Wait", null, true, true);
        }


        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);
            Log.d("TAG","===="+data);
            String temp[] = data.split(",");
            addr.setText(temp[0]);
            phone.setText(temp[1]);
            progressDialog.cancel();
        }


        @Override
        protected Void doInBackground(String... params) {

            String id = (String)params[0];



            String serverURL = "http://mediuu.cafe24.com/getAP.php";
            String postParameters ="id=" + id;


            try {

                URL url = new URL(serverURL);
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();


                httpURLConnection.setReadTimeout(5000);
                httpURLConnection.setConnectTimeout(5000);
                httpURLConnection.setRequestMethod("POST");
                //httpURLConnection.setRequestProperty("content-type", "application/json");
                httpURLConnection.setDoInput(true);
                httpURLConnection.connect();
                OutputStream outputStream = httpURLConnection.getOutputStream();
                outputStream.write(postParameters.getBytes("UTF-8"));
                outputStream.flush();
                outputStream.close();


/* 서버 -> 안드로이드 파라메터값 전달 */
                InputStream is = null;
                BufferedReader in = null;

                is = httpURLConnection.getInputStream();
                in = new BufferedReader(new InputStreamReader(is), 8 * 1024);
                String line = null;
                StringBuffer buff = new StringBuffer();
                while ( ( line = in.readLine() ) != null )
                {
                    buff.append(line + "\n");
                }
                data = buff.toString().trim();



            } catch (Exception e) {

                //  Log.d(TAG, "InsertData: Error ", e);

                e.printStackTrace();
            }
            return null;
        }
    }

    class AddParking extends AsyncTask<String, Void, Void> {
        ProgressDialog progressDialog;
        String data="";
        @Override
        protected void onPreExecute() {
            super.onPreExecute();

            progressDialog = ProgressDialog.show(getActivity(),
                    "Please Wait", null, true, true);
        }


        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);
            AlertDialog.Builder alertBuilder = new AlertDialog.Builder(getActivity());
            Log.d("TAG", "dndnddn" + data);
            progressDialog.dismiss();
            if (data.equals("1")) {
                Log.e("RESULT", "성공적으로 처리되었습니다!");
                alertBuilder
                        .setTitle("알림")
                        .setMessage("한개의 주차장만 등록가능합니다.")
                        .setCancelable(true)
                        .setPositiveButton("확인", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {


                            }
                        });
                AlertDialog dialog = alertBuilder.create();
                dialog.show();
            } else if (data.equals("0")) {
                Log.e("RESULT", "비밀번호가 일치하지 않습니다.");
                alertBuilder
                        .setTitle("알림")
                        .setMessage("주차장 등록성공!")
                        .setCancelable(true)
                        .setPositiveButton("확인", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                FragmentTransaction ft = getActivity().getSupportFragmentManager().beginTransaction();
                                ft.replace(R.id.content_fragment_layout, new ShakeFragment());
                                ft.commit();
                            }
                        });
                AlertDialog dialog = alertBuilder.create();
                dialog.show();
            }
        }



        @Override
        protected Void doInBackground(String... params) {


            String id = (String)params[0];
            String phone = (String)params[1];
            Log.d("TAG",id);
            String address = (String)params[2];
            String daddress = (String)params[3];
            String s_time = (String)params[4];
            String e_time = (String)params[5];
            String cost = (String)params[6];
            String serverURL = "http://mediuu.cafe24.com/addParking2.php";
            String postParameters = "id=" + id + "&phone=" + phone + "&address=" + address + "&daddress=" + daddress + "&s_time=" + s_time  + "&e_time=" + e_time  + "&cost=" + cost;
            Log.d("TAG",postParameters);

            try {

                URL url = new URL(serverURL);
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();


                httpURLConnection.setReadTimeout(5000);
                httpURLConnection.setConnectTimeout(5000);
                httpURLConnection.setRequestMethod("POST");
                //httpURLConnection.setRequestProperty("content-type", "application/json");
                httpURLConnection.setDoInput(true);
                httpURLConnection.connect();


                OutputStream outputStream = httpURLConnection.getOutputStream();
                outputStream.write(postParameters.getBytes("UTF-8"));
                outputStream.flush();
                outputStream.close();


                InputStream is = null;
                BufferedReader in = null;

                is = httpURLConnection.getInputStream();
                in = new BufferedReader(new InputStreamReader(is), 8 * 1024);
                String line = null;
                StringBuffer buff = new StringBuffer();
                while ( ( line = in.readLine() ) != null )
                {
                    buff.append(line + "\n");
                }
                data = buff.toString().trim();



            } catch (Exception e) {

                Log.d(TAG, "InsertData: Error ", e);


            }
            return null;

        }
    }
}
