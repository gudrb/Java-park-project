package hs8.pm;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class SignUpActivity extends AppCompatActivity {
    private EditText Name;
    private EditText Id;
    private EditText Pass;
    private EditText Phone;
    private EditText Address;

    private String name;
    private String address;
    private String id;
    private String pass;
    private String phone;

    final int REQUEST_ACT = 1;
    private static String TAG = "phptest_MainActivity";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        Name =(EditText)findViewById(R.id.sign_name);
        Id =(EditText)findViewById(R.id.sign_id);
        Pass =(EditText)findViewById(R.id.sign_pass);
        Phone =(EditText)findViewById(R.id.sign_phone);
        Address =(EditText)findViewById(R.id.sign_addr);
        Address.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SignUpActivity.this,AddressActivity.class);
                startActivityForResult(intent, REQUEST_ACT);
            }
        });
        Button buttonInsert = (Button)findViewById(R.id.signComplete);
        buttonInsert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                name = Name.getText().toString();
                address = Address.getText().toString();
                id = Id.getText().toString();
                pass = Pass.getText().toString();
                phone = Phone.getText().toString();

                if(name.equals("")||address.equals("")||id.equals("")||pass.equals("")||phone.equals(""))
                    Toast.makeText(SignUpActivity.this, "모든 정보를 입력해주세요.", Toast.LENGTH_SHORT).show();
                else {

                    InsertData task = new InsertData();
                    task.execute(name, id, pass, phone, address);
                }


            }
        });

    }
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK) {
            Address.setText("");
            return;
        }

        출처: http://developljy.tistory.com/16 [DEV_LJY 블로그]
        if (requestCode == REQUEST_ACT) {
            String resultMsg = data.getStringExtra("result_msg");
            Address.setText(resultMsg);
        }

    }

    class InsertData extends AsyncTask<String, Void, String> {
        ProgressDialog progressDialog;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();

            progressDialog = ProgressDialog.show(SignUpActivity.this,
                    "Please Wait", null, true, true);
        }


        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);

            progressDialog.dismiss();
            AlertDialog.Builder alertBuilder = new AlertDialog.Builder(SignUpActivity.this);
                alertBuilder
                        .setTitle("알림")
                        .setMessage("회원가입 성공!")
                        .setCancelable(true)
                        .setPositiveButton("확인", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {

                                finish();
                            }
                        });
                AlertDialog dialog = alertBuilder.create();
                dialog.show();

        }


        @Override
        protected String doInBackground(String... params) {

            String name = (String)params[0];
            String id = (String)params[1];
            String pass = (String)params[2];
            String phone = (String)params[3];
            String address = (String)params[4];


            String serverURL = "http://mediuu.cafe24.com/insert.php";
            String postParameters = "name=" + name + "&address=" + address + "&id=" + id  + "&pw=" + pass  + "&phone=" + phone;


            try {

                URL url = new URL(serverURL);
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();


                httpURLConnection.setReadTimeout(5000);
                httpURLConnection.setConnectTimeout(5000);
                httpURLConnection.setRequestMethod("POST");
                //httpURLConnection.setRequestProperty("content-type", "application/json");
                httpURLConnection.setDoInput(true);
                httpURLConnection.connect();


                OutputStream outputStream = httpURLConnection.getOutputStream();
                outputStream.write(postParameters.getBytes("UTF-8"));
                outputStream.flush();
                outputStream.close();


                int responseStatusCode = httpURLConnection.getResponseCode();
                Log.d(TAG, "POST response code - " + responseStatusCode);

                InputStream inputStream;
                if(responseStatusCode == HttpURLConnection.HTTP_OK) {
                    inputStream = httpURLConnection.getInputStream();
                }
                else{
                    inputStream = httpURLConnection.getErrorStream();
                }


                InputStreamReader inputStreamReader = new InputStreamReader(inputStream, "UTF-8");
                BufferedReader bufferedReader = new BufferedReader(inputStreamReader);

                StringBuilder sb = new StringBuilder();
                String line = null;

                while((line = bufferedReader.readLine()) != null){
                    sb.append(line);
                }


                bufferedReader.close();


                return sb.toString();


            } catch (Exception e) {

                Log.d(TAG, "InsertData: Error ", e);

                return new String("Error: " + e.getMessage());
            }

        }
    }
}
