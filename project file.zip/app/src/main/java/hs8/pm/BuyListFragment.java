package hs8.pm;


import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import static hs8.pm.R.id.listview;


/**
 * A simple {@link Fragment} subclass.
 */
public class BuyListFragment extends Fragment {

View view;
    MyAdapter mMyAdapter;
    private ListView mListView;
    public BuyListFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view =inflater.inflate(R.layout.fragment_buy_list, container, false);
        mMyAdapter = new MyAdapter();
        mListView = (ListView)view.findViewById(listview);
        BuyList task = new BuyList();
        task.execute(RMainActivity.id);
        return view;
    }
    public class BuyList extends AsyncTask<String, Integer, String> {

        ProgressDialog progressDialog;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog = ProgressDialog.show(getActivity(),
                    "Please Wait", null, true, true);
        }

        @Override
        protected String doInBackground(String... params) {
            StringBuilder jsonHtml = new StringBuilder();
            String id = params[0];



            String serverURL = "http://mediuu.cafe24.com/buylist.php";
            String postParameters ="id="+id;
            try{

                URL url = new URL(serverURL);
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();


                httpURLConnection.setReadTimeout(5000);
                httpURLConnection.setConnectTimeout(5000);
                httpURLConnection.setRequestMethod("POST");
                //httpURLConnection.setRequestProperty("content-type", "application/json");
                httpURLConnection.setDoInput(true);
                httpURLConnection.connect();
                OutputStream outputStream = httpURLConnection.getOutputStream();
                outputStream.write(postParameters.getBytes("UTF-8"));
                outputStream.flush();
                outputStream.close();

                InputStream is = null;
                BufferedReader in = null;

                is = httpURLConnection.getInputStream();
                in = new BufferedReader(new InputStreamReader(is), 8 * 1024);
                String line = null;
                StringBuffer buff = new StringBuffer();
                while ( ( line = in.readLine() ) != null )
                {
                    jsonHtml.append(line + "\n");
                }
                Log.d("TAG","여기오니");

            }catch (Exception ex){
                ex.printStackTrace();
            }
            return jsonHtml.toString();
        }


        protected void onPostExecute(String str) {

            try {

                // PHP에서 받아온 JSON 데이터를 JSON오브젝트로 변환

                JSONObject jObject = new JSONObject(str);

                // results라는 key는 JSON배열로 되어있다.

                JSONArray results = jObject.getJSONArray("results");

                String addr = "";
                String daddr = "";
                String  id="";
                String phone = "";
                String s_time="";
                String e_time="";
                String cost="";




                for ( int i = 0; i < results.length(); ++i ) {

                    JSONObject temp = results.getJSONObject(i);
                    id = temp.getString("ID");
                    phone = temp.getString("PHONE");
                    addr = temp.getString("ADDRESS");
                    daddr = temp.getString("DADDRESS");
                    s_time = temp.getString("S_TIME");
                    e_time = temp.getString("E_TIME");
                    cost = temp.getString("COST");

                    mMyAdapter.addItem(id,phone,addr,daddr,s_time,e_time,cost);

                }
                mListView.setAdapter(mMyAdapter);
                progressDialog.cancel();


            } catch (JSONException e) {

                e.printStackTrace();

            }

        }

    }

}
