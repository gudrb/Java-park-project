package hs8.pm;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentActivity;
import android.util.Log;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;

import java.net.URL;
import java.util.ArrayList;

public class MapActivity extends FragmentActivity implements OnMapReadyCallback {
    ParkingSearch task;
    ArrayList parkingArray;
    GoogleMap mMap;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map);
        parkingArray = new ArrayList();
        task = new ParkingSearch();
        task.execute();
        MapFragment mapFragment = (MapFragment) getFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

    }

    @Override
    public void onMapReady(GoogleMap mMap) {
        this.mMap = mMap;
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(MapActivity.this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, 1);

        }
        GPSInfo gps = new GPSInfo(MapActivity.this);
        if (gps.isGetLocation()) {
            double latitude = gps.getLatitude();
            double longitude = gps.getLongitude();
            LatLng latLng = new LatLng(latitude, longitude);
            mMap.moveCamera(CameraUpdateFactory.newLatLng(latLng));
            mMap.animateCamera(CameraUpdateFactory.zoomTo(10));
            MarkerOptions optFirst = new MarkerOptions();
            optFirst.position(latLng);// 위도 • 경도
            optFirst.title("현재 위치");// 제목 미리보기
            mMap.addMarker(optFirst).showInfoWindow();
        }

    }

    private void setUpMap(GoogleMap mMap){

            mMap.addMarker(new MarkerOptions().position(new LatLng(37.518794, 127.092855)).title("잠실역주차장").
                    snippet(((Parking) parkingArray.get(0)).getCnt() + "자리 비어있습니다"));
            mMap.addMarker(new MarkerOptions().position(new LatLng(37.654866, 127.048391)).title("창동역주차장").
                    snippet(((Parking) parkingArray.get(1)).getCnt() + "자리 비어있습니다"));
            mMap.addMarker(new MarkerOptions().position(new LatLng(37.485780, 126.901220)).title("구로디지털단지역주차장").
                    snippet(((Parking) parkingArray.get(2)).getCnt() + "자리 비어있습니다"));
            mMap.addMarker(new MarkerOptions().position(new LatLng(37.573093, 126.805288)).title("개화산역주차장").
                    snippet(((Parking) parkingArray.get(3)).getCnt() + "자리 비어있습니다"));
            mMap.addMarker(new MarkerOptions().position(new LatLng(37.488838, 127.099958)).title("수서역북주차장").
                    snippet(((Parking) parkingArray.get(4)).getCnt() + "자리 비어있습니다"));
            mMap.addMarker(new MarkerOptions().position(new LatLng(37.488702, 127.099958)).title("수서역남주차장").
                    snippet(((Parking) parkingArray.get(5)).getCnt() + "자리 비어있습니다"));
            mMap.addMarker(new MarkerOptions().position(new LatLng(37.471087, 127.128571)).title("복정역주차장").
                    snippet(((Parking) parkingArray.get(6)).getCnt() + "자리 비어있습니다"));
            mMap.addMarker(new MarkerOptions().position(new LatLng(37.540412, 127.002635)).title("한강진역주차장").
                    snippet(((Parking) parkingArray.get(7)).getCnt() + "자리 비어있습니다"));
            mMap.addMarker(new MarkerOptions().position(new LatLng(37.679775, 127.055925)).title("수락산역주차장").
                    snippet(((Parking) parkingArray.get(8)).getCnt() + "자리 비어있습니다"));
            mMap.addMarker(new MarkerOptions().position(new LatLng(37.607060, 127.094061)).title("봉화산역주차장").
                    snippet(((Parking) parkingArray.get(9)).getCnt() + "자리 비어있습니다"));
            mMap.addMarker(new MarkerOptions().position(new LatLng(37.616667, 127.080693)).title("화랑대역주차장").
                    snippet(((Parking) parkingArray.get(10)).getCnt() + "자리 비어있습니다"));
            mMap.addMarker(new MarkerOptions().position(new LatLng(37.572611, 127.036068)).title("구파발역주차장").
                    snippet(((Parking) parkingArray.get(11)).getCnt() + "자리 비어있습니다"));
            mMap.addMarker(new MarkerOptions().position(new LatLng(37.525731, 126.895132)).title("영등포구청역주차장").
                    snippet(((Parking) parkingArray.get(12)).getCnt() + "자리 비어있습니다"));
            mMap.addMarker(new MarkerOptions().position(new LatLng(37.495940, 127.069906)).title("학여울역주차장").
                    snippet(((Parking) parkingArray.get(13)).getCnt() + "자리 비어있습니다"));
            mMap.addMarker(new MarkerOptions().position(new LatLng(37.476268, 126.983743)).title("사당노외주차장").
                    snippet(((Parking) parkingArray.get(14)).getCnt() + "자리 비어있습니다"));
            mMap.addMarker(new MarkerOptions().position(new LatLng(37.572395, 126.994982)).title("종묘주차장").
                    snippet(((Parking) parkingArray.get(15)).getCnt() + "자리 비어있습니다"));
            mMap.addMarker(new MarkerOptions().position(new LatLng(37.578685, 126.799023)).title("개화역주차장").
                    snippet(((Parking) parkingArray.get(16)).getCnt() + "자리 비어있습니다"));
            mMap.addMarker(new MarkerOptions().position(new LatLng(37.540074, 126.943023)).title("마포유수지주차장").
                    snippet(((Parking) parkingArray.get(17)).getCnt() + "자리 비어있습니다"));
            mMap.addMarker(new MarkerOptions().position(new LatLng(37.539329, 127.125008)).title("천호역주차장").
                    snippet(((Parking) parkingArray.get(18)).getCnt() + "자리 비어있습니다"));
            mMap.addMarker(new MarkerOptions().position(new LatLng(37.535289, 126.965441)).title("용산주차빌딩").
                    snippet(((Parking) parkingArray.get(19)).getCnt() + "자리 비어있습니다"));
            mMap.addMarker(new MarkerOptions().position(new LatLng(37.464271, 126.906548)).title("남부여성주차장").
                    snippet(((Parking) parkingArray.get(20)).getCnt() + "자리 비어있습니다"));
            mMap.addMarker(new MarkerOptions().position(new LatLng(37.574398, 126.975811)).title("세종로주차장").
                    snippet(((Parking) parkingArray.get(21)).getCnt() + "자리 비어있습니다"));
            mMap.addMarker(new MarkerOptions().position(new LatLng(37.567049, 127.012038)).title("동대문주차장").
                    snippet(((Parking) parkingArray.get(22)).getCnt() + "자리 비어있습니다"));
            mMap.addMarker(new MarkerOptions().position(new LatLng(37.572305, 127.036068)).title("신대방역주차장").
                    snippet(((Parking) parkingArray.get(23)).getCnt() + "자리 비어있습니다"));


    }
    class ParkingSearch extends AsyncTask<Void, Void, Void> {
        final String key = "595157475a6a696e3438574c704f70";

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            setUpMap(mMap);
        }

        @Override
        protected Void doInBackground(Void... params) {
            String url="http://openapi.seoul.go.kr:8088/"+key+"/xml/PublicParkingAvaliable/1/25/";
            XmlPullParserFactory factory;
            XmlPullParser parser;
            URL xmlUrl;
            try{
                Log.d("TAG",url);
                boolean flagName = false;
                boolean flagCnt = false;
                boolean flagAddress = false;
                xmlUrl = new URL(url);
                xmlUrl.openConnection().getInputStream();
                factory =XmlPullParserFactory.newInstance();
                parser = factory.newPullParser();
                String name;
                String cnt;
                String address;
                Parking parking = new Parking();
                parser.setInput(xmlUrl.openStream(),"UTF-8");
                int eventType =parser.getEventType();
                while(eventType!=XmlPullParser.END_DOCUMENT){
                    if(eventType== XmlPullParser.START_DOCUMENT) {
                    }else if(eventType== XmlPullParser.START_TAG){
                        if (parser.getName().equals("PARK_NAME")) {
                            flagName = true;
                        }else if (parser.getName().equals("PARKING_CNT")) {
                            flagCnt = true;
                        }
                        else if(parser.getName().equals("PARK_ADDRESS")){
                            flagAddress= true;
                        }
                    }else if(eventType ==XmlPullParser.END_TAG){
                    }else if(eventType == XmlPullParser.TEXT){
                        if(flagName ==true){
                            parking = new Parking();
                            name = parser.getText();
                            Log.d("TAG",name);
                            parking.setName(name);
                            flagName = false;
                        } else if (flagCnt == true) {
                                cnt = parser.getText();
                                parking.setCnt(cnt);
                                flagCnt = false;
                            }

                        else if(flagAddress == true){
                            address =parser.getText();
                            parking.setAddress(address);
                            Log.d("TAG",address);
                            flagAddress=false;
                            parkingArray.add(parking);
                        }
                    }
                    eventType=parser.next();
                }
            }catch (Exception e){

            }
            return null;
        }
    }
}
